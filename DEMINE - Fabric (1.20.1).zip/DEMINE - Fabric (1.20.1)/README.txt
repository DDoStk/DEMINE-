Hey! This is a kind of tutorial for an enjoyable game on our server.
To set up all right, just check that you`ve installed the right version of zip.
(fabric if you want it for fabric, and forge if you wanna enjoy our server with forge)

1. Drag the "emotes" folder to your main folder ".minecraft"
2. Drag all the mods right into the "mods" folder.
3. Celebrate!